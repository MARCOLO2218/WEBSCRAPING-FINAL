@echo off
cd /d "%~dp0WEBSCRAPER PROD"
call EJECUTAR_SISTEMA_COMPLETO.bat

