@echo off
setlocal
set "URL=http://172.16.247.6:3031"
set "SHORTCUT=%USERPROFILE%\Desktop\Catalogo Comercial FACENCO PROD.url"
set "ICON=C:\Users\USER\source\repos\webscraper 7\WEBSCRAPER DEV\assets\facenco.ico"

echo [InternetShortcut] > "%SHORTCUT%"
echo URL=%URL% >> "%SHORTCUT%"
echo IconFile=%ICON% >> "%SHORTCUT%"
echo IconIndex=0 >> "%SHORTCUT%"

echo Acceso directo creado en el escritorio:
echo %SHORTCUT%
echo.
echo Este acceso abre:
echo %URL%
pause
