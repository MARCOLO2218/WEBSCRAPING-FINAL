﻿import { chromium, type Page } from 'playwright';
import ExcelJS from 'exceljs';
import { config as loadEnv } from 'dotenv';
import { Pool, type PoolClient } from 'pg';
import { existsSync } from 'node:fs';
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';

const envFile = existsSync('.env') ? '.env' : undefined;
if (envFile) {
  loadEnv({ path: envFile });
}

// URLs de origen.
// Si solo cambia la URL de una tienda ya existente, modifica estas constantes.
// Si agregas una tienda nueva, tambien debes crear su funcion scrape... y llamarla en main().
const FACENCO_SOURCE_URL = 'https://camasfacenco.com/';
const OLYMPIA_SOURCE_URL = 'https://camasolympiaonline.com/gt/';
const LA_COLCHONERIA_SOURCE_URL = 'https://lacolchoneria.com.gt/';
const SLEEP_GALLERY_SOURCE_URL = 'https://paises.sleepgalleryca.com/';
const MATTRESS_SOURCE_URL = 'https://mattress.com.gt/';
const BEDS_DREAMS_SOURCE_URL = 'https://www.bedsndreams.com/';
const FURNITURE_CITY_SOURCE_URL = 'https://www.furniturecity.com.gt/mattress-colchones/';
const LA_CURACAO_SOURCE_URL = 'https://www.lacuracaonline.com/guatemala/c/muebles/camas-y-colchones';
const MAX_GT_SOURCE_URL = 'https://www.max.com.gt/camas-y-colchones/c';
const ELEKTRA_GT_SOURCE_URL = 'https://www.elektra.com.gt/muebles-y-colchones/colchones/catgm1010101';
const WALMART_GT_SOURCE_URL = 'https://www.walmart.com.gt/search?q=colchon';
const CEMACO_GT_SOURCE_URL = 'https://www.cemaco.com/search?q=colchon';
// Cambia aqui la carpeta o el nombre de los archivos generados.
const OUTPUT_FILE = resolve('output/comparacion_colchones.csv');
const OUTPUT_XLSX_FILE = resolve('output/comparacion_colchones.xlsx');

type CatalogProduct = {
  productName: string;
  productUrl: string;
  sourceUrl: string;
  line: string;
  imageUrl: string;
  imageAlt: string;
};

type ProductDetails = {
  headline: string;
  description: string;
  warranty: string;
  benefits: string;
};

type CsvProduct = {
  source_site: string;
  brand: string;
  line: string;
  category: string;
  product_name: string;
  availability: string;
  regular_price: string;
  sale_price: string;
  discount: string;
  installment: string;
  product_url: string;
  source_url: string;
  headline: string;
  description: string;
  warranty: string;
  benefits: string;
  image_url: string;
  image_alt: string;
  scraped_at: string;
};

type DbConfig = {
  enabled: boolean;
  schema: string;
  missing: string[];
};

type ProductSelectorConfig = {
  sourceSite: string;
  brand: string;
  cardSelector: string;
  titleSelector: string;
  categorySelector?: string;
  lineSelector?: string;
  anchorSelector?: string;
  imageSelector?: string;
  regularPriceSelector?: string;
  salePriceSelector?: string;
  priceSelector?: string;
  discountSelector?: string;
  installmentSelector?: string;
};

type StoreScraper = {
  name: string;
  run: (page: Page) => Promise<CsvProduct[]>;
};

const columns: Array<keyof CsvProduct> = [
  'source_site',
  'brand',
  'line',
  'category',
  'product_name',
  'availability',
  'regular_price',
  'sale_price',
  'discount',
  'installment',
  'product_url',
  'source_url',
  'headline',
  'description',
  'warranty',
  'benefits',
  'image_url',
  'image_alt',
  'scraped_at',
];

const columnHeaders: Record<keyof CsvProduct, string> = {
  source_site: 'Sitio fuente',
  brand: 'Marca',
  line: 'Linea',
  category: 'Categoria',
  product_name: 'Producto',
  availability: 'Disponibilidad',
  regular_price: 'Precio regular',
  sale_price: 'Precio oferta',
  discount: 'Descuento',
  installment: 'Cuotas',
  product_url: 'URL producto',
  source_url: 'URL fuente',
  headline: 'Titulo',
  description: 'Descripcion',
  warranty: 'Garantia',
  benefits: 'Beneficios',
  image_url: 'URL imagen',
  image_alt: 'Texto imagen',
  scraped_at: 'Fecha scraping',
};

function cleanText(value: string | null | undefined): string {
  return (value ?? '').replace(/\s+/g, ' ').trim();
}

function toDbNullable(value: string | null | undefined): string | null {
  const cleaned = cleanText(value);
  const emptyMarkers = new Set(['', '-', 'n/a', 'na', 'null', 'undefined']);
  return emptyMarkers.has(cleaned.toLowerCase()) ? null : cleaned;
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function userFriendlyStoreError(storeName: string, technicalMessage: string): string {
  if (/ERR_CONNECTION_CLOSED|ERR_CONNECTION_RESET|ERR_NAME_NOT_RESOLVED|ERR_TIMED_OUT/i.test(technicalMessage)) {
    return `${storeName}: el sitio cerro la conexion o no respondio. Intentar mas tarde.`;
  }

  if (/Timeout|timed out|waiting until/i.test(technicalMessage)) {
    return `${storeName}: el sitio tardo demasiado en responder. Intentar mas tarde.`;
  }

  if (/interrupted by another navigation/i.test(technicalMessage)) {
    return `${storeName}: la navegacion fue interrumpida. Se recomienda reintentar.`;
  }

  return `${storeName}: no se genero informacion. Puede haber cambiado la pagina o estar bloqueando temporalmente.`;
}

function toAbsoluteUrl(url: string, baseUrl: string): string {
  try {
    return new URL(url, baseUrl).toString();
  } catch {
    return url;
  }
}

function csvEscape(value: string): string {
  return `"${value.replaceAll('"', '""')}"`;
}

function toCsv(rows: CsvProduct[]): string {
  const header = columns.map((column) => csvEscape(columnHeaders[column])).join(',');
  const body = rows
    .map((row) => columns.map((column) => csvEscape(row[column])).join(','))
    .join('\n');

  return `\uFEFF${header}\n${body}\n`;
}

function getDbConfig(): DbConfig {
  const schema = process.env.PGSCHEMA || 'catalogo';
  const requiredEnvVars = ['PGHOST', 'PGPORT', 'PGDATABASE', 'PGUSER', 'PGPASSWORD'];
  const missing = requiredEnvVars.filter((name) => !process.env[name]);

  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(schema)) {
    throw new Error('PGSCHEMA solo puede usar letras, numeros y guion bajo, y no puede iniciar con numero.');
  }

  return {
    enabled: missing.length === 0,
    schema,
    missing,
  };
}

function createDbPool(): Pool {
  const sslEnabled = (process.env.PGSSL || '').toLowerCase() === 'true';

  return new Pool({
    host: process.env.PGHOST,
    port: Number(process.env.PGPORT || 5432),
    database: process.env.PGDATABASE,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    ssl: sslEnabled ? { rejectUnauthorized: false } : false,
  });
}

function getGuatemalaWeekStart(): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Guatemala',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());

  const year = Number(parts.find((part) => part.type === 'year')?.value);
  const month = Number(parts.find((part) => part.type === 'month')?.value);
  const day = Number(parts.find((part) => part.type === 'day')?.value);
  const guatemalaDate = new Date(Date.UTC(year, month - 1, day));
  const dayOfWeek = guatemalaDate.getUTCDay();
  const daysSinceMonday = (dayOfWeek + 6) % 7;
  guatemalaDate.setUTCDate(guatemalaDate.getUTCDate() - daysSinceMonday);

  return guatemalaDate.toISOString().slice(0, 10);
}

async function ensurePostgresTables(client: PoolClient, schema: string): Promise<void> {
  await client.query(`CREATE SCHEMA IF NOT EXISTS ${schema}`);

  await client.query(`
    CREATE TABLE IF NOT EXISTS ${schema}.scraping_runs (
      id BIGSERIAL PRIMARY KEY,
      run_uuid UUID,
      semana_run INTEGER,
      semana_inicio DATE,
      started_at TIMESTAMP DEFAULT NOW(),
      source_process TEXT,
      total_products INTEGER
    )
  `);

  await client.query(`
    CREATE TABLE IF NOT EXISTS ${schema}.productos_catalogo (
      id BIGSERIAL PRIMARY KEY,
      run_id BIGINT REFERENCES ${schema}.scraping_runs(id),
      run_uuid UUID,
      semana_run INTEGER,
      semana_inicio DATE,
      sitio_fuente TEXT,
      marca TEXT,
      linea TEXT,
      categoria TEXT,
      producto TEXT,
      disponibilidad TEXT,
      precio_regular TEXT,
      precio_oferta TEXT,
      descuento TEXT,
      cuotas TEXT,
      url_producto TEXT,
      url_fuente TEXT,
      titulo TEXT,
      descripcion TEXT,
      garantia TEXT,
      beneficios TEXT,
      url_imagen TEXT,
      texto_imagen TEXT,
      fecha_scraping TIMESTAMP,
      creado_en TIMESTAMP DEFAULT NOW()
    )
  `);

  await client.query(`ALTER TABLE ${schema}.scraping_runs ADD COLUMN IF NOT EXISTS run_uuid UUID`);
  await client.query(`ALTER TABLE ${schema}.scraping_runs ADD COLUMN IF NOT EXISTS semana_run INTEGER`);
  await client.query(`ALTER TABLE ${schema}.scraping_runs ADD COLUMN IF NOT EXISTS semana_inicio DATE`);
  await client.query(`ALTER TABLE ${schema}.productos_catalogo ADD COLUMN IF NOT EXISTS registro_uuid UUID`);
  await client.query(`ALTER TABLE ${schema}.productos_catalogo ADD COLUMN IF NOT EXISTS run_uuid UUID`);
  await client.query(`ALTER TABLE ${schema}.productos_catalogo ADD COLUMN IF NOT EXISTS semana_run INTEGER`);
  await client.query(`ALTER TABLE ${schema}.productos_catalogo ADD COLUMN IF NOT EXISTS semana_inicio DATE`);
  await client.query(`DROP INDEX IF EXISTS ${schema}.ux_productos_catalogo_url_dia`);
  await client.query(`DROP INDEX IF EXISTS ${schema}.ux_scraping_runs_semana_run`);
  await client.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_scraping_runs_run_uuid ON ${schema}.scraping_runs (run_uuid)`);
  await client.query(`CREATE INDEX IF NOT EXISTS ix_scraping_runs_semana_inicio ON ${schema}.scraping_runs (semana_inicio)`);
  await client.query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_productos_catalogo_registro_uuid ON ${schema}.productos_catalogo (registro_uuid)`);
  await client.query(`CREATE INDEX IF NOT EXISTS ix_productos_catalogo_fecha_id ON ${schema}.productos_catalogo (fecha_scraping DESC, id DESC)`);
  await client.query(`CREATE INDEX IF NOT EXISTS ix_productos_catalogo_producto ON ${schema}.productos_catalogo (producto)`);
}

async function saveProductsToPostgres(rows: CsvProduct[]): Promise<void> {
  const config = getDbConfig();

  if (!config.enabled) {
    console.log(`PostgreSQL no configurado. Faltan variables: ${config.missing.join(', ')}`);
    console.log('Se omite guardado en base de datos.');
    return;
  }

  const pool = createDbPool();
  const client = await pool.connect();

  try {
    await client.query('BEGIN');
    await ensurePostgresTables(client, config.schema);

    const runUuid = randomUUID();
    const weekStart = getGuatemalaWeekStart();
    const weekResult = await client.query<{ semana_run: string }>(
      `SELECT COALESCE(
         (SELECT semana_run FROM ${config.schema}.scraping_runs WHERE semana_inicio = $1 ORDER BY id ASC LIMIT 1),
         (SELECT COALESCE(MAX(semana_run), 0) + 1 FROM ${config.schema}.scraping_runs)
       ) AS semana_run`,
      [weekStart],
    );
    const runWeek = Number(weekResult.rows[0]?.semana_run ?? 1);

    const runResult = await client.query<{ id: string }>(
      `INSERT INTO ${config.schema}.scraping_runs (run_uuid, semana_run, semana_inicio, source_process, total_products)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id`,
      [runUuid, runWeek, weekStart, 'typescript-scraper-camas', rows.length],
    );
    const runId = runResult.rows[0]?.id;

    const insertSql = `
      INSERT INTO ${config.schema}.productos_catalogo (
        registro_uuid,
        run_uuid,
        semana_run,
        semana_inicio,
        run_id,
        sitio_fuente,
        marca,
        linea,
        categoria,
        producto,
        disponibilidad,
        precio_regular,
        precio_oferta,
        descuento,
        cuotas,
        url_producto,
        url_fuente,
        titulo,
        descripcion,
        garantia,
        beneficios,
        url_imagen,
        texto_imagen,
        fecha_scraping
      )
      VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
        $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
        $21, $22, $23, $24
      )
    `;

    let insertedRows = 0;

    for (const row of rows) {
      const result = await client.query(insertSql, [
        randomUUID(),
        runUuid,
        runWeek,
        weekStart,
        runId,
        toDbNullable(row.source_site),
        toDbNullable(row.brand),
        toDbNullable(row.line),
        toDbNullable(row.category),
        toDbNullable(row.product_name),
        toDbNullable(row.availability),
        toDbNullable(row.regular_price),
        toDbNullable(row.sale_price),
        toDbNullable(row.discount),
        toDbNullable(row.installment),
        toDbNullable(row.product_url),
        toDbNullable(row.source_url),
        toDbNullable(row.headline),
        toDbNullable(row.description),
        toDbNullable(row.warranty),
        toDbNullable(row.benefits),
        toDbNullable(row.image_url),
        toDbNullable(row.image_alt),
        toDbNullable(row.scraped_at),
      ]);

      if (result.rowCount && result.rowCount > 0) {
        insertedRows += result.rowCount;
      }
    }

    await client.query('COMMIT');
    console.log(`Run ID de esta consulta: Semana ${runWeek} (run_id ${runId})`);
    console.log(`Inicio de semana: ${weekStart}`);
    console.log(`UUID tecnico de esta consulta: ${runUuid}`);
    console.log(`PostgreSQL actualizado: ${insertedRows} productos insertados.`);
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

async function writeExcel(rows: CsvProduct[], outputFile: string): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Scraper de camas';
  workbook.created = new Date();

  const worksheet = workbook.addWorksheet('Productos', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });

  worksheet.columns = columns.map((column) => ({
    header: columnHeaders[column],
    key: column,
    width: Math.min(Math.max(columnHeaders[column].length + 4, 16), 45),
  }));

  for (const row of rows) {
    worksheet.addRow(row);
  }

  worksheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: columns.length },
  };

  const headerRow = worksheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF107C41' },
  };
  headerRow.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };

  worksheet.eachRow((row, rowNumber) => {
    row.eachCell((cell) => {
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFE5E7EB' } },
        left: { style: 'thin', color: { argb: 'FFE5E7EB' } },
        bottom: { style: 'thin', color: { argb: 'FFE5E7EB' } },
        right: { style: 'thin', color: { argb: 'FFE5E7EB' } },
      };
      cell.alignment = {
        vertical: 'top',
        wrapText: rowNumber === 1 || ['description', 'benefits', 'headline'].includes(String(cell.col)),
      };
    });
  });

  worksheet.getColumn('product_name').width = 32;
  worksheet.getColumn('product_url').width = 48;
  worksheet.getColumn('source_url').width = 42;
  worksheet.getColumn('headline').width = 42;
  worksheet.getColumn('description').width = 60;
  worksheet.getColumn('benefits').width = 48;
  worksheet.getColumn('image_url').width = 48;
  worksheet.getColumn('scraped_at').width = 26;

  await workbook.xlsx.writeFile(outputFile);
}

async function goto(page: Page, url: string): Promise<void> {
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60_000 });
  await page.waitForLoadState('networkidle', { timeout: 30_000 }).catch(() => undefined);
}

function uniqueValues(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

function inferFacencoLine(text: string, url: string): string {
  const value = cleanText(text || url);
  const fromText = value.match(/\blinea\s+([a-z0-9\s-]+)/i)?.[1] ?? '';
  const fromUrl = url.match(/linea-([^/?#]+)/i)?.[1] ?? '';
  const rawLine = fromText || fromUrl;

  return rawLine
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

async function extractFacencoCatalogUrls(page: Page, sourceUrl: string): Promise<string[]> {
  return page.evaluate((sourceUrl) => {
    const absolute = (url: string) => {
      try {
        return new URL(url, sourceUrl).toString();
      } catch {
        return '';
      }
    };

    return Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href]'))
      .map((anchor) => absolute(anchor.getAttribute('href') ?? ''))
      .filter((url) => {
        if (!url.startsWith(sourceUrl)) {
          return false;
        }

        return /\/linea-|\/producto|\/colchon|\/cama/i.test(new URL(url).pathname);
      });
  }, sourceUrl);
}

async function extractFacencoCatalogProducts(page: Page, sourceUrl: string): Promise<CatalogProduct[]> {
  return page.evaluate((sourceUrl) => {
    const clean = (value: string | null | undefined) => (value ?? '').replace(/\s+/g, ' ').trim();
    const absolute = (url: string) => {
      try {
        return new URL(url, sourceUrl).toString();
      } catch {
        return url;
      }
    };
    const nameFromUrl = (url: string) => {
      try {
        const slug = new URL(url, sourceUrl).pathname.replace(/^\/|\/$/g, '').split('/').pop() ?? '';
        return slug
          .replace(/-\d+$/g, '')
          .replace(/-/g, ' ')
          .replace(/\b\w/g, (letter) => letter.toUpperCase());
      } catch {
        return '';
      }
    };
    const productHeadings = Array.from(document.querySelectorAll('h2'))
      .map((heading) => clean(heading.textContent))
      .filter((text) => {
        const lowerText = text.toLowerCase();
        return text
          && lowerText !== 'enlaces'
          && lowerText !== 'facenco'
          && !lowerText.startsWith('direcci')
          && !lowerText.includes('trabaja con nosotros');
      });

    const linkScript = Array.from(document.scripts)
      .map((script) => script.textContent ?? '')
      .find((text) => text.includes('et_link_options_data'));

    const match = linkScript?.match(/et_link_options_data\s*=\s*(\[[\s\S]*?\]);/);
    const linkData = match ? JSON.parse(match[1]) as Array<{ class: string; url: string }> : [];

    const products = linkData
      .map((item, index) => {
        const container = document.querySelector(`.${CSS.escape(item.class)}`);
        const heading = clean(container?.querySelector('h1,h2,h3')?.textContent);
        const image = container?.querySelector('img');
        const imageSrc = image?.getAttribute('src') || image?.getAttribute('data-src') || '';
        const imageAlt = clean(image?.getAttribute('alt'));
        const productUrl = absolute(item.url);
        const visibleHeading = productHeadings.length > linkData.length
          ? productHeadings.at(index + productHeadings.length - linkData.length) ?? ''
          : '';
        const fallbackName = productHeadings.length <= linkData.length ? nameFromUrl(productUrl) : heading;

        return {
          productName: visibleHeading || fallbackName || heading || imageAlt || nameFromUrl(productUrl),
          productUrl,
          sourceUrl,
          line: '',
          imageUrl: imageSrc ? absolute(imageSrc) : '',
          imageAlt,
        };
      })
      .filter((product) => product.productName && product.productUrl);

    if (products.length > 0) {
      return products;
    }

    return Array.from(document.querySelectorAll('h2'))
      .map((heading) => {
        const text = clean(heading.textContent);
        const container = heading.closest('.et_pb_column, .et_pb_module, section, article, div');
        const anchor = container?.querySelector<HTMLAnchorElement>('a[href]');
        const image = container?.querySelector('img');
        const imageSrc = image?.getAttribute('src') || image?.getAttribute('data-src') || '';

        return {
          productName: text,
          productUrl: anchor?.href ? absolute(anchor.href) : '',
          sourceUrl,
          line: '',
          imageUrl: imageSrc ? absolute(imageSrc) : '',
          imageAlt: clean(image?.getAttribute('alt')),
        };
      })
      .filter((product) => product.productName && product.productUrl);
  }, sourceUrl);
}

async function extractProductDetails(page: Page): Promise<ProductDetails> {
  return page.evaluate(() => {
    const clean = (value: string | null | undefined) => (value ?? '').replace(/\s+/g, ' ').trim();
    const ignored = /^(enlaces|facenco|otros beneficios|regresar|direcci[oÃ³]n|trabaja con nosotros)$/i;
    const main = document.querySelector('main, article, #main-content') ?? document.body;
    const headings = Array.from(main.querySelectorAll('h1,h2,h3'))
      .map((node) => clean(node.textContent))
      .filter((text) => text && !ignored.test(text));

    const paragraphs = Array.from(main.querySelectorAll('p'))
      .map((node) => clean(node.textContent))
      .filter((text) => text.length > 45 && !/tel\s*\(/i.test(text));

    const imageAlts = Array.from(main.querySelectorAll('img'))
      .map((image) => clean(image.getAttribute('alt')))
      .filter(Boolean);

    const bodyText = clean(main.textContent);
    const warrantyFromText = bodyText.match(/\b\d+\s*aÃ±os?\s+de\s+garant[iÃ­]a\b/i)?.[0] ?? '';
    const warrantyFromImage = imageAlts.find((alt) => /garant[iÃ­]a/i.test(alt)) ?? '';

    const benefitPairs = Array.from(main.querySelectorAll('h2,h3'))
      .map((heading) => {
        const title = clean(heading.textContent);
        if (!title || ignored.test(title) || /energy/i.test(title)) {
          return '';
        }

        let sibling = heading.parentElement?.nextElementSibling ?? heading.nextElementSibling;
        let description = '';

        for (let i = 0; sibling && i < 4; i += 1) {
          const text = clean(sibling.textContent);
          if (sibling.matches('p') && text.length > 20) {
            description = text;
            break;
          }
          sibling = sibling.nextElementSibling;
        }

        return description ? `${title}: ${description}` : title;
      })
      .filter(Boolean);

    const headline = headings.slice(0, 2).join(' - ');
    const description = paragraphs[0] ?? '';
    const benefits = Array.from(new Set(benefitPairs)).join(' | ');

    return {
      headline,
      description,
      warranty: warrantyFromText || warrantyFromImage,
      benefits,
    };
  });
}

async function extractOlympiaProducts(page: Page): Promise<CsvProduct[]> {
  return page.evaluate((sourceUrl) => {
    const clean = (value: string | null | undefined) => (value ?? '').replace(/\s+/g, ' ').trim();
    const absolute = (url: string) => {
      try {
        return new URL(url, sourceUrl).toString();
      } catch {
        return url;
      }
    };

    return Array.from(document.querySelectorAll<HTMLElement>('.ol-products-grid article.ol-card'))
      .map((card) => {
        const title = clean(card.querySelector('.ol-card-title')?.textContent);
        const category = clean(card.querySelector('.ol-card-cat')?.textContent);
        const discount = clean(card.querySelector('.ol-badge')?.textContent);
        const regularPrice = clean(card.querySelector('.ol-price-old')?.textContent);
        const salePrice = clean(card.querySelector('.ol-price-new')?.textContent)
          || clean(card.querySelector('.ol-card-price')?.textContent);
        const installment = clean(card.querySelector('.ol-cuotas-box')?.textContent);
        const anchor = card.querySelector<HTMLAnchorElement>('a.ol-card-btn, a.ol-card-img-wrap, a[href]');
        const image = card.querySelector<HTMLImageElement>('img');
        const imageUrl = image?.currentSrc || image?.src || image?.getAttribute('src') || '';
        const imageAlt = clean(image?.getAttribute('alt'));

        return {
          source_site: 'Camas Olympia Online GT',
          brand: 'Olympia',
          line: '',
          category,
          product_name: title || imageAlt,
          availability: 'Listado en tienda online',
          regular_price: regularPrice,
          sale_price: salePrice,
          discount,
          installment,
          product_url: anchor?.href ? absolute(anchor.href) : '',
          source_url: sourceUrl,
          headline: '',
          description: '',
          warranty: '',
          benefits: '',
          image_url: imageUrl ? absolute(imageUrl) : '',
          image_alt: imageAlt,
          scraped_at: '',
        };
      })
      .filter((product) => product.product_name && product.product_url);
  }, OLYMPIA_SOURCE_URL);
}

async function scrapeFacenco(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, FACENCO_SOURCE_URL);
  const discoveredCatalogUrls = await extractFacencoCatalogUrls(page, FACENCO_SOURCE_URL);
  const catalogUrls = uniqueValues(
    discoveredCatalogUrls.length > 0 ? discoveredCatalogUrls : [FACENCO_SOURCE_URL],
  );
  const catalogProductsByKey = new Map<string, CatalogProduct>();

  for (const catalogUrl of catalogUrls) {
    await goto(page, catalogUrl);
    const pageTitle = await page.title();
    const line = inferFacencoLine(pageTitle, catalogUrl);
    const products = await extractFacencoCatalogProducts(page, catalogUrl);

    for (const product of products) {
      const productKey = `${catalogUrl}|${product.productName}|${product.productUrl}`;
      catalogProductsByKey.set(productKey, {
        ...product,
        sourceUrl: catalogUrl,
        line: product.line || line,
      });
    }
  }

  const catalogProducts = Array.from(catalogProductsByKey.values());
  const rows: CsvProduct[] = [];

  for (const product of catalogProducts) {
    await goto(page, product.productUrl);
    const details = await extractProductDetails(page);

    rows.push({
      source_site: 'FACENCO',
      brand: 'FACENCO',
      line: product.line,
      category: 'Colchones',
      product_name: cleanText(product.productName),
      availability: 'Listado en catálogo',
      regular_price: '',
      sale_price: '',
      discount: '',
      installment: '',
      product_url: toAbsoluteUrl(product.productUrl, product.sourceUrl),
      source_url: product.sourceUrl,
      headline: details.headline,
      description: details.description,
      warranty: details.warranty,
      benefits: details.benefits,
      image_url: product.imageUrl,
      image_alt: product.imageAlt,
      scraped_at: scrapedAt,
    });
  }

  return rows;
}

async function scrapeOlympia(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, OLYMPIA_SOURCE_URL);
  const rows = await extractOlympiaProducts(page);

  return rows.map((row) => ({
    ...row,
    scraped_at: scrapedAt,
  }));
}

async function extractLaColchoneriaProducts(page: Page): Promise<CsvProduct[]> {
  return page.evaluate((sourceUrl) => {
    const clean = (value: string | null | undefined) => (value ?? '').replace(/\s+/g, ' ').trim();
    const absolute = (url: string) => {
      try {
        return new URL(url, sourceUrl).toString();
      } catch {
        return url;
      }
    };
    const productCategory = (name: string, sectionTitle: string) => {
      if (sectionTitle) {
        return sectionTitle;
      }
      if (/colch[oó]n|colchon/i.test(name)) {
        return 'Colchones';
      }
      if (/^cama\b/i.test(name)) {
        return 'Camas';
      }
      if (/almohada/i.test(name)) {
        return 'Almohadas';
      }
      if (/protector|s[aá]bana|sabana|duvet|edred[oó]n|cubrecama/i.test(name)) {
        return 'Ropa de cama';
      }
      if (/sill[oó]n|sofa|sof[aá]|camastron|camastr[oó]n/i.test(name)) {
        return 'Muebles';
      }
      return '';
    };
    const sectionHeading = (card: Element) => {
      const section = card.closest('section, .shopify-section, [id^="shopify-section"]');
      const heading = section?.querySelector('h1,h2,h3,.section-title,.title');
      return clean(heading?.textContent)
        .replace(/^#+\s*/, '')
        .replace(/\s+\d+\s*$/, '');
    };
    const imageUrl = (image: HTMLImageElement | null) => {
      if (!image) {
        return '';
      }
      const template = image.getAttribute('data-src');
      if (template) {
        return template.replace('{width}', '720');
      }
      return image.currentSrc || image.src || image.getAttribute('src') || '';
    };
    const moneyAmounts = (value: string) => value.match(/Q\s?[\d,]+(?:\.\d{2})?/g) ?? [];

    const rows = Array.from(document.querySelectorAll<HTMLElement>('.product-card.js-product-card'))
      .map((card) => {
        const nameAnchor = card.querySelector<HTMLAnchorElement>('.product-card__name[href]');
        const image = card.querySelector<HTMLImageElement>('img');
        const productName = clean(nameAnchor?.textContent || image?.getAttribute('alt'));
        const priceText = clean(card.querySelector('.product-card__price')?.textContent);
        const amounts = moneyAmounts(priceText);
        const salePrice = clean(card.querySelector('.product-card__price strong')?.textContent) || amounts[0] || '';
        const regularPrice = clean(card.querySelector('.product-card__regular-price')?.textContent) || amounts[1] || '';
        const discount = clean(card.querySelector('.product-tag-sale, .product-label')?.textContent);
        const installment = clean(card.querySelector('.badge-finance')?.textContent);
        const size = clean(card.querySelector('[id^="size_slot_"]')?.textContent);
        const sectionTitle = sectionHeading(card);
        const url = nameAnchor?.href || card.querySelector<HTMLAnchorElement>('a[href]')?.href || '';
        const img = imageUrl(image);

        return {
          source_site: 'La Colchonería Guatemala',
          brand: 'La Colchonería',
          line: size,
          category: productCategory(productName, sectionTitle),
          product_name: productName,
          availability: 'Listado en tienda online',
          regular_price: regularPrice,
          sale_price: salePrice,
          discount,
          installment,
          product_url: url ? absolute(url) : '',
          source_url: sourceUrl,
          headline: '',
          description: '',
          warranty: '',
          benefits: '',
          image_url: img ? absolute(img) : '',
          image_alt: clean(image?.getAttribute('alt')),
          scraped_at: '',
        };
      })
      .filter((product) => product.product_name && product.product_url);

    const unique = new Map<string, CsvProduct>();
    for (const row of rows) {
      if (!unique.has(row.product_url)) {
        unique.set(row.product_url, row);
      }
    }

    return Array.from(unique.values());
  }, LA_COLCHONERIA_SOURCE_URL);
}

async function scrapeLaColchoneria(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, LA_COLCHONERIA_SOURCE_URL);
  const rows = await extractLaColchoneriaProducts(page);

  return rows.map((row) => ({
    ...row,
    scraped_at: scrapedAt,
  }));
}

async function extractCardProducts(
  page: Page,
  sourceUrl: string,
  config: ProductSelectorConfig,
): Promise<CsvProduct[]> {
  return page.evaluate(({ sourceUrl, config }) => {
    const clean = (value: string | null | undefined) => (value ?? '').replace(/\s+/g, ' ').trim();
    const absolute = (url: string) => {
      try {
        return new URL(url, sourceUrl).toString();
      } catch {
        return url;
      }
    };
    const firstText = (root: Element, selector?: string) => {
      if (!selector) {
        return '';
      }
      return clean(root.querySelector(selector)?.textContent);
    };
    const productCategory = (name: string, fallback: string) => {
      if (fallback) {
        return fallback;
      }
      if (/colch[oó]n|colchon|mattress/i.test(name)) {
        return 'Colchones';
      }
      if (/cama|base/i.test(name)) {
        return 'Camas';
      }
      if (/almohada|pillow/i.test(name)) {
        return 'Almohadas';
      }
      if (/protector|frazada|edred[oó]n|comforter/i.test(name)) {
        return 'Ropa de cama';
      }
      return '';
    };
    const imageUrl = (image: HTMLImageElement | null) => {
      if (!image) {
        return '';
      }
      const srcset = image.getAttribute('data-srcset') || image.getAttribute('srcset') || '';
      const srcsetFirst = srcset.split(',').map((item) => item.trim().split(/\s+/)[0]).find(Boolean) ?? '';
      const src = image.currentSrc || image.src || image.getAttribute('data-src') || image.getAttribute('src') || srcsetFirst;
      return src && !src.startsWith('data:') ? absolute(src) : '';
    };

    const rows = Array.from(document.querySelectorAll<HTMLElement>(config.cardSelector))
      .map((card) => {
        const title = firstText(card, config.titleSelector);
        const anchor = card.querySelector<HTMLAnchorElement>(config.anchorSelector ?? 'a[href]');
        const image = card.querySelector<HTMLImageElement>(config.imageSelector ?? 'img');
        const category = productCategory(title, firstText(card, config.categorySelector));
        const regularPrice = firstText(card, config.regularPriceSelector);
        const salePrice = firstText(card, config.salePriceSelector) || firstText(card, config.priceSelector);
        const discount = firstText(card, config.discountSelector);
        const installment = firstText(card, config.installmentSelector);
        const line = firstText(card, config.lineSelector);

        return {
          source_site: config.sourceSite,
          brand: config.brand,
          line,
          category,
          product_name: title,
          availability: 'Listado en tienda online',
          regular_price: regularPrice,
          sale_price: salePrice,
          discount,
          installment,
          product_url: anchor?.href ? absolute(anchor.href) : '',
          source_url: sourceUrl,
          headline: '',
          description: '',
          warranty: '',
          benefits: '',
          image_url: imageUrl(image),
          image_alt: clean(image?.getAttribute('alt')),
          scraped_at: '',
        };
      })
      .filter((product) => product.product_name && product.product_url);

    const unique = new Map<string, CsvProduct>();
    for (const row of rows) {
      if (!unique.has(row.product_url)) {
        unique.set(row.product_url, row);
      }
    }

    return Array.from(unique.values());
  }, { sourceUrl, config });
}

async function scrapeSleepGallery(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, SLEEP_GALLERY_SOURCE_URL);
  const rows = await extractCardProducts(page, SLEEP_GALLERY_SOURCE_URL, {
    sourceSite: 'Sleep Gallery Guatemala',
    brand: 'Sleep Gallery',
    cardSelector: 'article.sg-card',
    titleSelector: '.sg-card-title',
    categorySelector: '.sg-card-cat',
    lineSelector: '.sg-badge-comfort',
    anchorSelector: 'a.sg-card-btn, a.sg-card-img-wrap, a[href]',
    imageSelector: 'img',
    regularPriceSelector: '.sg-price-old',
    salePriceSelector: '.sg-price-new',
    priceSelector: '.sg-card-price',
    discountSelector: '.sg-badge',
  });

  return rows.map((row) => ({
    ...row,
    scraped_at: scrapedAt,
  }));
}

async function scrapeMattress(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, MATTRESS_SOURCE_URL);
  const rows = await extractCardProducts(page, MATTRESS_SOURCE_URL, {
    sourceSite: 'Mattress Guatemala',
    brand: 'Mattress',
    cardSelector: 'li.product',
    titleSelector: '.woocommerce-loop-product__title',
    categorySelector: '.product-category, .posted_in',
    anchorSelector: 'a.woocommerce-LoopProduct-link, a[href]',
    imageSelector: 'img',
    regularPriceSelector: 'del .woocommerce-Price-amount, del',
    salePriceSelector: 'ins .woocommerce-Price-amount, ins',
    priceSelector: '.price',
    discountSelector: '.onsale, .nm-shop-loop-product-title-action',
  });

  return rows.map((row) => ({
    ...row,
    scraped_at: scrapedAt,
  }));
}

async function scrapeBedsDreams(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, BEDS_DREAMS_SOURCE_URL);
  const rows = await extractCardProducts(page, BEDS_DREAMS_SOURCE_URL, {
    sourceSite: 'Beds & Dreams',
    brand: 'Beds & Dreams',
    cardSelector: '.product-card.js-product-card',
    titleSelector: '.product-card__name',
    categorySelector: '.product-card__type, .product-card__vendor',
    anchorSelector: '.product-card__name[href], a[href]',
    imageSelector: 'img',
    regularPriceSelector: '.product-card__regular-price, s',
    salePriceSelector: '.product-card__price',
    priceSelector: '.product-card__price',
    discountSelector: '.product-label, .product-tag-sale',
  });

  return rows.map((row) => ({
    ...row,
    scraped_at: scrapedAt,
  }));
}

async function extractFurnitureCityCatalogUrls(page: Page): Promise<string[]> {
  return page.evaluate((sourceUrl) => {
    const absolute = (url: string) => {
      try {
        return new URL(url, sourceUrl).toString();
      } catch {
        return '';
      }
    };

    return Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href]'))
      .map((anchor) => absolute(anchor.getAttribute('href') ?? ''))
      .filter((url) => /\/product-category\/.*colchones/i.test(url) || /\/producto\//i.test(url));
  }, FURNITURE_CITY_SOURCE_URL);
}

async function scrapeFurnitureCity(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  await goto(page, FURNITURE_CITY_SOURCE_URL);
  const catalogUrls = uniqueValues([
    FURNITURE_CITY_SOURCE_URL,
    ...await extractFurnitureCityCatalogUrls(page),
  ]);
  const rowsByUrl = new Map<string, CsvProduct>();

  for (const catalogUrl of catalogUrls) {
    if (/\/producto\//i.test(catalogUrl)) {
      rowsByUrl.set(catalogUrl, {
        source_site: 'Furniture City Guatemala',
        brand: 'Furniture City',
        line: '',
        category: 'Colchones',
        product_name: cleanText(catalogUrl.split('/').filter(Boolean).pop()?.replace(/-/g, ' ')),
        availability: 'Listado en tienda online',
        regular_price: '',
        sale_price: '',
        discount: '',
        installment: '',
        product_url: catalogUrl,
        source_url: FURNITURE_CITY_SOURCE_URL,
        headline: '',
        description: '',
        warranty: '',
        benefits: '',
        image_url: '',
        image_alt: '',
        scraped_at: scrapedAt,
      });
      continue;
    }

    await goto(page, catalogUrl);
    const rows = await extractCardProducts(page, catalogUrl, {
      sourceSite: 'Furniture City Guatemala',
      brand: 'Furniture City',
      cardSelector: '.product-small.col.has-hover, li.product',
      titleSelector: '.woocommerce-loop-product__title, .product-title',
      categorySelector: '.product-cat',
      anchorSelector: '.woocommerce-LoopProduct-link, a[href]',
      imageSelector: 'img',
      regularPriceSelector: 'del .woocommerce-Price-amount, del',
      salePriceSelector: 'ins .woocommerce-Price-amount, ins',
      priceSelector: '.price',
      discountSelector: '.onsale',
    });

    for (const row of rows) {
      rowsByUrl.set(row.product_url, {
        ...row,
        scraped_at: scrapedAt,
      });
    }
  }

  return Array.from(rowsByUrl.values());
}

// Filtro comercial FACENCO.
// Aqui puedes ajustar que productos interesan para el catalogo comparativo.
const BED_PRODUCT_INCLUDE_WORDS = [
  'colchon', 'colchón', 'mattress', 'cama', 'bed', 'base', 'box spring', 'boxspring',
  'almohada', 'pillow', 'protector', 'funda', 'sabana', 'sábana', 'cobertor',
  'edredon', 'edredón', 'duvet', 'frazada', 'comforter', 'cabecera', 'respaldo',
  'sofa cama', 'sofá cama', 'sillon cama', 'sillón cama', 'futon', 'futón',
  'litera', 'sleep', 'dormitorio', 'recamara', 'recámara', 'celaje', 'celajes',
];

const BED_PRODUCT_EXCLUDE_WORDS = [
  'laptop', 'notebook', 'computadora', 'pc gamer', 'monitor', 'teclado', 'mouse',
  'celular', 'telefono', 'teléfono', 'smartphone', 'tablet', 'ipad', 'iphone',
  'televisor', 'tv ', 'smart tv', 'pantalla', 'proyector', 'camara', 'cámara',
  'refrigeradora', 'refrigerador', 'lavadora', 'secadora', 'estufa', 'cocina',
  'microondas', 'licuadora', 'freidora', 'cafetera', 'batidora', 'audio', 'bocina',
  'parlante', 'audifono', 'audífono', 'consola', 'playstation', 'xbox', 'nintendo',
  'impresora', 'router', 'ups', 'bicicleta', 'moto', 'llanta', 'juguete',
];

function normalizeCatalogText(value: string): string {
  return cleanText(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function hasRelevantBedProduct(row: CsvProduct): boolean {
  const haystack = normalizeCatalogText([
    row.product_name,
    row.category,
    row.line,
    row.headline,
    row.description,
    row.product_url,
    row.source_url,
    row.image_alt,
  ].filter(Boolean).join(' '));

  if (!haystack) {
    return false;
  }

  const hasIncludedWord = BED_PRODUCT_INCLUDE_WORDS.some((word) => haystack.includes(normalizeCatalogText(word)));
  if (!hasIncludedWord) {
    return false;
  }

  return !BED_PRODUCT_EXCLUDE_WORDS.some((word) => haystack.includes(normalizeCatalogText(word)));
}

function hasQuetzalPrice(row: CsvProduct): boolean {
  const priceText = cleanText([
    row.regular_price,
    row.sale_price,
    row.discount,
    row.installment,
  ].filter(Boolean).join(' '));

  return /(^|\s|[^A-Za-z])Q\s?\d|GTQ|Quetzal/i.test(priceText);
}

function filterGuatemalaQuetzalRows(rows: CsvProduct[]): CsvProduct[] {
  return rows.filter((row) => hasQuetzalPrice(row) && hasRelevantBedProduct(row));
}

async function scrapeGenericGuatemalaStore(
  page: Page,
  scrapedAt: string,
  sourceUrl: string,
  sourceSite: string,
  brand: string,
): Promise<CsvProduct[]> {
  await goto(page, sourceUrl);
  const rows = await extractCardProducts(page, sourceUrl, {
    sourceSite,
    brand,
    cardSelector: [
      'li.product-item',
      '.product-item-info',
      '.product-card',
      '.product',
      '.vtex-product-summary-2-x-container',
      '[data-testid*="product"]',
      'article',
    ].join(', '),
    titleSelector: [
      '.product-item-link',
      '.product-name',
      '.product-title',
      '.product-card__name',
      '.vtex-product-summary-2-x-productBrand',
      '[data-testid="product-title"]',
      'h2',
      'h3',
      'a[title]',
    ].join(', '),
    categorySelector: '.category, .product-category, .breadcrumb, [class*="category"]',
    anchorSelector: 'a[href]',
    imageSelector: 'img',
    regularPriceSelector: '.old-price, .was-price, del, .price-old, [class*="oldPrice"], [class*="listPrice"]',
    salePriceSelector: '.special-price, .sale-price, ins, .price-final_price, [class*="sellingPrice"], [class*="salePrice"]',
    priceSelector: '.price, .price-box, .product-price, [class*="price"], [data-testid*="price"]',
    discountSelector: '.discount, .badge, .label, .tag, [class*="discount"], [class*="promo"]',
    installmentSelector: '.installment, .cuotas, [class*="installment"], [class*="cuota"]',
  });

  return filterGuatemalaQuetzalRows(rows).map((row) => ({
    ...row,
    scraped_at: scrapedAt,
  }));
}

async function scrapeLaCuracao(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  return scrapeGenericGuatemalaStore(page, scrapedAt, LA_CURACAO_SOURCE_URL, 'La Curacao Guatemala', 'La Curacao');
}

async function scrapeMaxGt(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  return scrapeGenericGuatemalaStore(page, scrapedAt, MAX_GT_SOURCE_URL, 'MAX Guatemala', 'MAX');
}

async function scrapeElektraGt(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  return scrapeGenericGuatemalaStore(page, scrapedAt, ELEKTRA_GT_SOURCE_URL, 'Elektra Guatemala', 'Elektra');
}

async function scrapeWalmartGt(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  return scrapeGenericGuatemalaStore(page, scrapedAt, WALMART_GT_SOURCE_URL, 'Walmart Guatemala', 'Walmart');
}

async function scrapeCemacoGt(page: Page, scrapedAt: string): Promise<CsvProduct[]> {
  return scrapeGenericGuatemalaStore(page, scrapedAt, CEMACO_GT_SOURCE_URL, 'Cemaco Guatemala', 'Cemaco');
}

function hasDollarPrice(row: CsvProduct): boolean {
  const priceText = normalizeCatalogText([
    row.regular_price,
    row.sale_price,
    row.discount,
    row.installment,
  ].filter(Boolean).join(' '));

  return /(^|\s|[^A-Za-z])\$\s?\d|usd|dolar|dolares|dÃ³lar|dÃ³lares/.test(priceText);
}

function isFacencoRow(row: CsvProduct): boolean {
  return normalizeCatalogText(row.source_site) === 'facenco' || normalizeCatalogText(row.brand) === 'facenco';
}

function shouldKeepCatalogRow(row: CsvProduct): boolean {
  if (!hasRelevantBedProduct(row)) {
    return false;
  }

  if (isFacencoRow(row)) {
    return true;
  }

  if (hasDollarPrice(row)) {
    return false;
  }

  return hasQuetzalPrice(row);
}

function filterFinalCatalogRows(rows: CsvProduct[]): CsvProduct[] {
  const unique = new Map<string, CsvProduct>();

  for (const row of rows) {
    if (!shouldKeepCatalogRow(row)) {
      continue;
    }

    const key = row.product_url || `${row.source_site}|${row.product_name}|${row.regular_price}|${row.sale_price}`;
    if (!unique.has(key)) {
      unique.set(key, row);
    }
  }

  return Array.from(unique.values());
}

async function main(): Promise<void> {
  const browser = await chromium.launch({ headless: true });

  try {
    const scrapedAt = new Date().toISOString();
    // MAIN: aqui se unen todos los scrapers.
    // Para agregar una tienda nueva:
    // 1. Crea una constante con su URL arriba del archivo.
    // 2. Crea una funcion scrapeNombreTienda(page, scrapedAt).
    // 3. Agrega aqui una linea como: ...await scrapeNombreTienda(page, scrapedAt),
    const storeScrapers: StoreScraper[] = [
      { name: 'FACENCO', run: (storePage) => scrapeFacenco(storePage, scrapedAt) },
      { name: 'Camas Olympia Online GT', run: (storePage) => scrapeOlympia(storePage, scrapedAt) },
      { name: 'La Colchoneria Guatemala', run: (storePage) => scrapeLaColchoneria(storePage, scrapedAt) },
      { name: 'Sleep Gallery Guatemala', run: (storePage) => scrapeSleepGallery(storePage, scrapedAt) },
      { name: 'Mattress Guatemala', run: (storePage) => scrapeMattress(storePage, scrapedAt) },
      { name: 'Beds & Dreams', run: (storePage) => scrapeBedsDreams(storePage, scrapedAt) },
      { name: 'Furniture City Guatemala', run: (storePage) => scrapeFurnitureCity(storePage, scrapedAt) },
      { name: 'La Curacao Guatemala', run: (storePage) => scrapeLaCuracao(storePage, scrapedAt) },
      { name: 'MAX Guatemala', run: (storePage) => scrapeMaxGt(storePage, scrapedAt) },
      { name: 'Elektra Guatemala', run: (storePage) => scrapeElektraGt(storePage, scrapedAt) },
      { name: 'Walmart Guatemala', run: (storePage) => scrapeWalmartGt(storePage, scrapedAt) },
      { name: 'Cemaco Guatemala', run: (storePage) => scrapeCemacoGt(storePage, scrapedAt) },
    ];

    const rows: CsvProduct[] = [];
    const failures: string[] = [];

    for (const store of storeScrapers) {
      const storePage = await browser.newPage({
        userAgent:
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36',
      });

      try {
        console.log(`Iniciando ${store.name}...`);
        const storeRows = await store.run(storePage);
        rows.push(...storeRows);
        console.log(`OK ${store.name}: ${storeRows.length} productos.`);
      } catch (error) {
        const technical = errorMessage(error);
        const message = userFriendlyStoreError(store.name, technical);
        failures.push(message);
        console.error(`ADVERTENCIA: ${message}`);
        console.error(`DETALLE_TECNICO ${store.name}: ${technical}`);
      } finally {
        await storePage.close().catch(() => undefined);
      }
    }

    const filteredRows = filterFinalCatalogRows(rows);

    if (filteredRows.length === 0) {
      throw new Error(`No se pudo generar informacion util. Se eliminaron productos fuera de cama o con precios en dolares. ${failures.join(' | ')}`);
    }

    await mkdir(dirname(OUTPUT_FILE), { recursive: true });
    await writeFile(OUTPUT_FILE, toCsv(filteredRows), 'utf8');
    await writeExcel(filteredRows, OUTPUT_XLSX_FILE);
    await saveProductsToPostgres(filteredRows);

    console.log(`Productos extraidos antes de filtro: ${rows.length}`);
    console.log(`Productos guardados despues de filtro: ${filteredRows.length}`);
    if (failures.length > 0) {
      console.log(`Tiendas con advertencia: ${failures.length}`);
      for (const failure of failures) {
        console.log(`ADVERTENCIA: ${failure}`);
      }
    }
    console.log(`CSV generado: ${OUTPUT_FILE}`);
    console.log(`Excel generado: ${OUTPUT_XLSX_FILE}`);
  } finally {
    await browser.close();
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});





